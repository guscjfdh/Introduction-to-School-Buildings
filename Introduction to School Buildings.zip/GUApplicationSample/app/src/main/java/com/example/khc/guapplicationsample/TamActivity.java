package com.example.khc.guapplicationsample;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class TamActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tam);
    }
    public void onFire1(View view){
        Intent intFire1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://fire.gwangju.ac.kr/"));
        startActivity(intFire1);
    }
    public void onCivil1(View view){
        Intent intCivil1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://civil.gwangju.ac.kr/"));
        startActivity(intCivil1);
    }
    public void onUrban1(View view){
        Intent intUrban1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://urban.gwangju.ac.kr/"));
        startActivity(intUrban1);
    }
}
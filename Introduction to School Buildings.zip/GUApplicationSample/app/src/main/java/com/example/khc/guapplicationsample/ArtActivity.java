package com.example.khc.guapplicationsample;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class ArtActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_art);
    }
    public void onSport1(View view){
        Intent intSport1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://sport.gwangju.ac.kr/"));
        startActivity(intSport1);
    }
    public void onGid1(View view){
        Intent intGid1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://gid.gwangju.ac.kr/"));
        startActivity(intGid1);
    }
}

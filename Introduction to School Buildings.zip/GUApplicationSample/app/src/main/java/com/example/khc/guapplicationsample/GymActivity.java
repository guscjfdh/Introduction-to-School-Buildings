package com.example.khc.guapplicationsample;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class GymActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gym);
    }
    public void onSport1(View view){
        Intent intSport1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://sport.gwangju.ac.kr/"));
        startActivity(intSport1);
    }
    public void onPla1(View view){
        Intent intPla1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://pla.gwangju.ac.kr/"));
        startActivity(intPla1);
    }
    public void onDst1(View view){
        Intent intDst1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://dst.gwangju.ac.kr/"));
        startActivity(intDst1);
    }
}

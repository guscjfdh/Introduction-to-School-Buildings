package com.example.khc.guapplicationsample;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class SungActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sung);
    }
    public void onWel1(View view){
        Intent intWel1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://welfare.gwangju.ac.kr/"));
        startActivity(intWel1);
    }
    public void onYcle1(View view){
        Intent intYcle1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://ycle.gwangju.ac.kr/"));
        startActivity(intYcle1);
    }
    public void onEce1(View view){
        Intent intEce1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://ece.gwangju.ac.kr/"));
        startActivity(intEce1);
    }
    public void onNr1(View view){
        Intent intNr1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://nr.gwangju.ac.kr/"));
        startActivity(intNr1);
    }
    public void onDocs1(View view){
        Intent intDocs1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://docs.gwangju.ac.kr/"));
        startActivity(intDocs1);
    }
    public void onPla1(View view){
        Intent intPla1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://pla.gwangju.ac.kr/"));
        startActivity(intPla1);
    }
    public void onJmc1(View view){
        Intent intJmc1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://jmc.gwangju.ac.kr/"));
        startActivity(intJmc1);
    }
    public void onCivil1(View view){
        Intent intCivil1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://civil.gwangju.ac.kr/"));
        startActivity(intCivil1);
    }
    public void onArc1(View view){
        Intent intArc1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://arc.gwangju.ac.kr/"));
        startActivity(intArc1);
    }
    public void onItcar1(View view){
        Intent intItcar1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://itcar.gwangju.ac.kr/"));
        startActivity(intItcar1);
    }
    public void onFjd1(View view){
        Intent intFjd1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://fjd.kr/div/"));
        startActivity(intFjd1);
    }
    public void onBeauty1(View view){
        Intent intBeauty1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://beauty.gwangju.ac.kr/"));
        startActivity(intBeauty1);
    }
}

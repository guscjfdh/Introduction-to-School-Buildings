package com.example.khc.guapplicationsample;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class TwoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);
    }
    public void onNr1(View view){
        Intent intNr1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://nr.gwangju.ac.kr/"));
        startActivity(intNr1);
    }
    public void onCyfo1(View view){
        Intent intcyfo1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://cyfo.gwangju.ac.kr"));
        startActivity(intcyfo1);
    }
    public void onArc1(View view){
        Intent intArc1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://arc.gwangju.ac.kr/"));
        startActivity(intArc1);
    }
    public void onDst1(View view){
        Intent intDst1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://dst.gwangju.ac.kr/"));
        startActivity(intDst1);
    }
    public void onBio1(View view){
        Intent intBio1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://biofood.gwangju.ac.kr/"));
        startActivity(intBio1);
    }
    public void onItcar1(View view){
        Intent intItcar1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://itcar.gwangju.ac.kr/"));
        startActivity(intItcar1);
    }
    public void onMe1(View view){
        Intent intMe1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://me.gwangju.ac.kr/"));
        startActivity(intMe1);
    }
}

package com.example.khc.guapplicationsample;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.GetChars;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onButton1(View view){
        Intent int1 = new Intent(getApplicationContext(), SubActivity.class);
        startActivity(int1);
    }
    public void onButton2(View view){
        Intent int2 = new Intent(getApplicationContext(), FirstActivity.class);
        startActivity(int2);
    }
    public void onButton3(View view){
        Intent int3 = new Intent(getApplicationContext(), TwoActivity.class);
        startActivity(int3);
    }
    public void onButton4(View view){
        Intent int4 = new Intent(getApplicationContext(), ArtActivity.class);
        startActivity(int4);
    }
    public void onButton5(View view){
        Intent int5 = new Intent(getApplicationContext(), GymActivity.class);
        startActivity(int5);
    }
    public void onButton6(View view){
        Intent int6 = new Intent(getApplicationContext(), InsActivity.class);
        startActivity(int6);
    }
    public void onButton7(View view){
        Intent int7 = new Intent(getApplicationContext(), TamActivity.class);
        startActivity(int7);
    }
    public void onButton8(View view){
        Intent int8 = new Intent(getApplicationContext(), KukiActivity.class);
        startActivity(int8);
    }
    public void onButton9(View view){
        Intent int9 = new Intent(getApplicationContext(), SungActivity.class);
        startActivity(int9);
    }
    public void onButton10(View view){
        Intent int10 = new Intent(getApplicationContext(), HangActivity.class);
        startActivity(int10);
    }
    public void onButton11(View view){
        Intent int11 = new Intent(getApplicationContext(), SliActivity.class);
        startActivity(int11);
    }
    public void onButton12(View view){
        Intent int12 = new Intent(getApplicationContext(), HakActivity.class);
        startActivity(int12);
    }
    public void onImage1(View view){
        Intent image1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.gwangju.ac.kr"));
        startActivity(image1);
    }
}

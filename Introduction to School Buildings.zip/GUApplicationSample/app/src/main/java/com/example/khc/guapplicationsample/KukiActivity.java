package com.example.khc.guapplicationsample;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class KukiActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kuki);
    }
    public void onPla1(View view){
        Intent intPla1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://pla.gwangju.ac.kr"));
        startActivity(intPla1);
    }
    public void onMun1(View view){
        Intent intMun1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://muncre.gwangju.ac.kr"));
        startActivity(intMun1);
    }
    public void onDst1(View view){
        Intent intDst1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://dst.gwangju.ac.kr/"));
        startActivity(intDst1);
    }
    public void onGud1(View view){
        Intent intGud1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://gud2m.com/"));
        startActivity(intGud1);
    }
    public void onGid1(View view){
        Intent intGid1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://gid.gwangju.ac.kr/"));
        startActivity(intGid1);
    }
    public void onFjd1(View view){
        Intent intFjd1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://fjd.kr/div/"));
        startActivity(intFjd1);
    }
    public void onGjuphoto1(View view){
        Intent intGjuphoto1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://gjuphoto.com/"));
        startActivity(intGjuphoto1);
    }
}

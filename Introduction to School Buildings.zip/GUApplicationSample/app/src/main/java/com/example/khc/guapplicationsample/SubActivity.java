package com.example.khc.guapplicationsample;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import org.w3c.dom.Text;

public class SubActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
    }
    public void onCyfo1(View view){
        Intent intcyfo1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://cyfo.gwangju.ac.kr"));
        startActivity(intcyfo1);
    }
    public void onIit1(View view){
        Intent intIit1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://iit.gwangju.ac.kr/"));
        startActivity(intIit1);
    }
    public void onBio1(View view){
        Intent intBio1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://biofood.gwangju.ac.kr/"));
        startActivity(intBio1);
    }
    public void onTax1(View view){
        Intent intTax1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://tax.gwangju.ac.kr/"));
        startActivity(intTax1);
    }
    public void onWel1(View view){
        Intent intWel1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://welfare.gwangju.ac.kr/"));
        startActivity(intWel1);
    }
    public void onYcle1(View view){
        Intent intYcle1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://ycle.gwangju.ac.kr/"));
        startActivity(intYcle1);
    }
    public void onEce1(View view){
        Intent intEce1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://ece.gwangju.ac.kr/"));
        startActivity(intEce1);
    }
    public void onGjuot1(View view){
        Intent intGjuot1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://gjuot.gwangju.ac.kr/"));
        startActivity(intGjuot1);
    }
    public void onSlp1(View view){
        Intent intSlp1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://slp.gwangju.ac.kr/"));
        startActivity(intSlp1);
    }
    public void onGjuphoto1(View view){
        Intent intGjuphoto1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://gjuphoto.com/"));
        startActivity(intGjuphoto1);
    }
    public void onPsy1(View view){
        Intent intPsy1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://psy.gwangju.ac.kr/"));
        startActivity(intPsy1);
    }
    public void onSport1(View view){
        Intent intSport1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://sport.gwangju.ac.kr/"));
        startActivity(intSport1);
    }
    public void onFn1(View view){
        Intent intFn1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://fn.gwangju.ac.kr/"));
        startActivity(intFn1);
    }
    public void onMedic1(View view){
        Intent intMedic1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://medic.gwangju.ac.kr/"));
        startActivity(intMedic1);
    }
    public void onGlobal1(View view){
        Intent intGlobal1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://global.gwangju.ac.kr/"));
        startActivity(intGlobal1);
    }
    public void onKor1(View view){
        Intent intKor1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://korean.gwangju.ac.kr/"));
        startActivity(intKor1);
    }
    public void onDlis1(View view){
        Intent intDlis1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://dlis.gwangju.ac.kr/"));
        startActivity(intDlis1);
    }
    public void onBiz1(View view){
        Intent intBiz1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://biz.gwangju.ac.kr/"));
        startActivity(intBiz1);
    }
    public void onKjumu1(View view){
        Intent intKjumu1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://kjumusic.gwangju.ac.kr/"));
        startActivity(intKjumu1);
    }
    public void onEbiz1(View view){
        Intent intEbiz1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://ebiz.gwangju.ac.kr/"));
        startActivity(intEbiz1);
    }
    public void onDref1(View view){
        Intent intDref1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://dref.gwangju.ac.kr/"));
        startActivity(intDref1);
    }
    public void onHtl1(View view){
        Intent intHtl1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://htltour.gwangju.ac.kr/"));
        startActivity(intHtl1);
    }
    public void onAir1(View view){
        Intent intAir1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://airline.gwangju.ac.kr/"));
        startActivity(intAir1);
    }
    public void onJori1(View view){
        Intent intJori1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://jori.gwangju.ac.kr/"));
        startActivity(intJori1);
    }
    public void onElec1(View view){
        Intent intElec1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://elec.gwangju.ac.kr/"));
        startActivity(intElec1);
    }
    public void onArc1(View view){
        Intent intArc1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://arc.gwangju.ac.kr/"));
        startActivity(intArc1);
    }
    public void onItcar1(View view){
        Intent intItcar1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://itcar.gwangju.ac.kr/"));
        startActivity(intItcar1);
    }
    public void onMe1(View view){
        Intent intMe1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://me.gwangju.ac.kr/"));
        startActivity(intMe1);
    }
}
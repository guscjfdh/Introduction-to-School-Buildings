package com.example.khc.guapplicationsample;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class FirstActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
    }
    public void onIit1(View view){
        Intent intIit1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://iit.gwangju.ac.kr/"));
        startActivity(intIit1);
    }
    public void onCyfo1(View view){
        Intent intcyfo1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://cyfo.gwangju.ac.kr"));
        startActivity(intcyfo1);
    }
    public void onAir1(View view){
        Intent intAir1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://airline.gwangju.ac.kr/"));
        startActivity(intAir1);
    }
    public void onJori1(View view){
        Intent intJori1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://jori.gwangju.ac.kr/"));
        startActivity(intJori1);
    }
    public void onCse1(View view){
        Intent intCse1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://cse.gwangju.ac.kr/"));
        startActivity(intCse1);
    }
    public void onSw1(View view){
        Intent intSw1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://sw.gwangju.ac.kr/"));
        startActivity(intSw1);
    }
    public void onElec1(View view){
        Intent intElec1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://elec.gwangju.ac.kr/"));
        startActivity(intElec1);
    }
    public void onDst1(View view){
        Intent intDst1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://dst.gwangju.ac.kr/"));
        startActivity(intDst1);
    }
}

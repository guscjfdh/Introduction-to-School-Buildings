package com.example.khc.guapplicationsample;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class SliActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sli);
    }
    public void onFn1(View view){
        Intent intFn1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://fn.gwangju.ac.kr/"));
        startActivity(intFn1);
    }
    public void onJori1(View view){
        Intent intJori1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://jori.gwangju.ac.kr/"));
        startActivity(intJori1);
    }
}
